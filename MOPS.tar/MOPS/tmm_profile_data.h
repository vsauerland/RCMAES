extern PetscInt *gNumProfiles, *gStartIndices, *gEndIndices, *lStartIndices, *lEndIndices;
extern PetscInt *lProfileLength, lNumProfiles, lSize, numPrevProfiles, totalNumProfiles;
extern PetscBool useProfiles;
